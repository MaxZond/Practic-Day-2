﻿using Practic_Api_1.Models;

namespace DataAccess.Interfaces
{
    public interface IUserRepository : IRepositoryBase<User>
    {
    }
}
